# ShipmentSure: Predicting On-Time Delivery Using Supplier Data

ShipmentSure is a machine learning-based logistics prediction system that estimates whether a shipment will be delivered on time or delayed using supplier and shipment-related features.

## Features
- Predicts on-time delivery status
- Uses supplier and shipment data
- Streamlit-based interactive dashboard
- Professional black-gold UI
- Displays delivery confidence and outcome

## Files
- `train_model.py` → model training script
- `app.py` → Streamlit frontend and backend integration
- `utils.py` → helper functions for preprocessing and prediction
- `style.css` → UI styling
- `.streamlit/config.toml` → Streamlit theme config

## Installation
```bash
pip install -r requirements.txt